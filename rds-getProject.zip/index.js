const sql = require('mssql')

exports.handler = async (event) => {
    const config = {
        user: "admin",
        password: "admincass",
        server: "cass.cs3alnknc3j0.us-east-1.rds.amazonaws.com",
        database: "cass",
        options: {
            trustedconnection: true,
            enableArithAbort: true,
            instancename: "SQLEXPRESS",
        },
        port: 1433,
    };

    async function getData() {
        try {
            let pool = await sql.connect(config);
            let results = await pool.request().query("SELECT * from Project");
            return results.recordsets;
        } catch (error) {
            console.log(error);
        }
    }
    return await getData();
};